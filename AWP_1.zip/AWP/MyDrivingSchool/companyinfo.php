<!DOCTYPE html>
<html>
<head>
	<title>Company Infromation</title>
</head>
<?php include "includes/header.php"; ?>
 <?php include "includes/navigation.php"; ?>

<body>
	<br><br>
	<hr>
	<form>
		<table border="1">
			<tr>
				<td>
	
					<img src="links/mld.png">
				</td>

				<td>
					<h3 align="center">
						My driving school was started since 2010 year.Also we have 11 years experiences with the driving side as well as we have well educated trainers and good staff services.
					</h3> 
				</td>
			</tr>
			<tr>
			</tr>

		</table>

	</form>
	<br>
<?php include "includes/footer.php"; ?>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
	<title>Terms And Condition</title>
</head>

<body>
<?php include "includes/header.php"; ?>
 <?php include "includes/navigation.php"; ?>
	<form>
		<table>
			<tr>
				<td>
					<center><img src="links/privacy.png" width="500" height="500">
						<img src="links/pol.jpg" height="150" width="400">
				</td>
				<td>
					<p>
						<h2> Privacy policy</h2>
<b> We are committed to safeguarding the privacy of our website visitors; in this policy we explain how we will treat your personal information.</b><br><br>

(01)This document was created using a template from SEQ Legal<br><br>
(02)We use Google Analytics, we (or Google) may collect, store and use the following kinds of personal information :<br><br>
	* Information about your computer and about your visits to and use of this website (including [your IP address, geographical location, browser type and version, operating system, 
		referral source, length of visit, page views and website navigation paths])<br><br>
(03)Our website includes hyperlinks to, and details of, third party websites.<br><br>
(04)We have no control over, and are not responsible for, the privacy policies and practices of third parties.<br><br>
(05)We will not, without your express consent, supply your personal information to any third party for the purpose of their or any other third party's direct marketing.<br><br>
<h5> Our website uses third party cookies</h5>
	* A cookie is a file containing an identifier (a string of letters and numbers) that is sent by a web server to a web browser and is stored by the browser. The identifier is then sent back to the server each time the browser requests a page from the server.<br><br>
	* Cookies do not typically contain any information that personally identifies a user, but personal information that we store about you may be linked to the information stored in and obtained from cookies.<br><br>
<H2>Your acceptance of these terms</H2> 
By using Our Code World, you signify your assent to this Privacy Policy. If you do not agree with this Privacy Policy, please do not use the Site. Your continued use of the Site following the posting of changes to these terms will mean you accept those changes.

<h2> Childrens</h2>
Our Code World is not directed at individuals under thirteen (18) years of age, and we do not intend to collect any personally-identifiable information from such individuals.

<h2>Changes to this privacy policy</h2>
We may update this policy at any time by simply posting such addition or modification on the Site.
					</p>
				</td>
			</tr>
		</table>
	</form>
	
</center>
<?php include "includes/footer.php"; ?>
</body>
</html>
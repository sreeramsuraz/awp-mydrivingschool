<!DOCTYPE html>
<html>
<head>
	<title>About Us</title>
</head>
<body>
<?php include "includes/header.php"; ?>
 <?php include "includes/navigation.php"; ?>

	<center>
		<H2>About Us</H2>
	</center>
	<form>
		<table>
			<tr>
				<td>
					<img src="images/about.jpg ">
				</td>
				<td>
					<b>Who we are</b><br><br>
<h3>My Driving School "the institute of driver training" first commenced its operations in manage the learners and people who want to take a good learners school as well as the admin that means the owner of the we application can select the best and near learners to the people and connect them both.</h3>

				</td>
			</tr>
			
		</table>
	</form>

<?php include "includes/footer.php"; ?>
</body>
</html>





















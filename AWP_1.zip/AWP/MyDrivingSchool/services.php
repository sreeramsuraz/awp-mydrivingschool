<!DOCTYPE html>
<html>
<head>
	<title>Services</title>
</head>
<body bgcolor="gray">
<?php include "includes/header.php"; ?>
 <?php include "includes/navigation.php"; ?>
	<center>
		<H1>Our Vision</H1>
	</center>
	
				<center><img src="images/course5.jpg "></center>
	<form>
		<table>
			<tr>
				<td>
					<h3>FULL COURSE WITH LICENSE</h3><br><br>
This package is for beginners for Auto or Manual Transmission vehicles
License Category - Dual Purpose License (Cars, Vans, SUV )Total no of lessons - Manual Car - 20 lessons.Auto Car - 12 lessons.Duration - 30 mnts per lesson.All our classes are individually trained,So that the students will get a personalized training session. No group lessons.
Instructors - All are professionally qualified and well experienced trainers with fluent in English, Tamil,Sinhala languages
Lady Teachers - Well experienced lady teachers are available for female pupils.Vehicles - All our vehicles are new and fully air conditioned.Application process - We assist all our pupils for medical, and RMV Documentation process.



					
				</td>
				<td>
					<h3>REFRESHER COURSE</h3><br><br>
Has it been a while since you drove ? Or you want to sharpen your skills? Then the refresher course is the perfect one for you!
We will give you confidence and sharpen your skills, So that you can deal with increasing amount of traffic on our roads and drive with confidence. Relearning safe driving principals reduces the risk to your self and others.
Duration - 30 months per lesson in our vehicle. The pupil can also relearn to drive with your own vehicle as well.
Individual training by our instructors.
Lady teacher service for ladies.
Number of lessons will be decided after a free text drive with the pupil.

				</td>
			</tr>
			<tr>
				<td>
					<h3>V.I.P SERVICE.</h3><br><br>
License category - Dual Purpose - For Cars, Vans, SUV
No of lessons - 30 Lessons for Manual gear transmission.
 20 Lessons for Auto gear transmission.
Duration- 30 Mnts or 1 hour lessons per session.
Time- Lessons can booked at pupils convenience and the days.
Lady teacher service for ladies.
Fully air conditioned vehicles are provided at all times.
Pick and drop service from your Office, Home or University (Colombo City limits only) other areas at an extra cost.
Driving License application process, Written exam and Practical Test - We will accompany the pupil in our vehicle.

					
				</td>
				<td>
					<h3>MOTOR CYCLE COURSE</h3><br><br>

For the pupils following the Beginners and refresher course.
10 Lessons course.
Half an hour duration per lesson.
Individually trained.
				</td>
			</tr>
			
		</table>
	</form>
<?php include "includes/footer.php"; ?>

</body>
</html>














<!DOCTYPE html>
<html>
<head>
	<title>FAQ</title>
</head>


<body>

<?php include "includes/header.php"; ?>
 <?php include "includes/navigation.php"; ?>

	<center><img src="links/faq.jpg" height="200" width="1000"></center>

	<center>
	<label><h1>HOW TO LEARN DRIVING</h1></label>

	<select>
 	<option value="volvo">come and follow us ,you can learning driving safty and very cheap,we have simple method for learning driving</option>
  	
 	
</select><br><br>

	<label><h1>HOW TO PAY US</h1></label>

	<select>
 	<option value="from money">from money</option>
  	<option value="from credit cad">from credit cad</option>
  	<option value="from check">from check</option>
  	<option value="from money transfer">from money transfer</option>
</select><br><br>


<label><h1>CLASSES OF DRIVING LICENCE</h1></label>

	<select>
 	<option value="volvo">Light motor cycles of which Engine Capacity does not exceeds 100CC</option>
  	<option value="saab">Motorcycles of which Engine capacity exceeds 100CC</option>
  	<option value="mercedes">Heavy Motor Lorry – Combination of motor lorry and trailer(s) including articulated vehicles and its trailer(s) of which maximum authorized tare of the trailer exceeds 750kg and gross vehicle weight exceeds 3500kg</option>
  	<option value="audi">Motor Coach where the seating capacity does not exceed 33 seats inclusive of the driver's seat; motor vehicles in this class may be combined with a trailer having a maximum authorized tare which does not exceed 750kg</option>
</select><br><br>
	</center>
	</table>
	</form>

	<?php include "includes/footer.php"; ?>
</body>
</html>
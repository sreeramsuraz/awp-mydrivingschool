create campus database and import campus.sql file

admin

username:  Admin
Password:  Admin

Learners

username:  Learners1
Password:  123456

user

username:  user
Password:  123456